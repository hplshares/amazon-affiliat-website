'use client'

import { useState } from 'react'
import { CATEGORIES, PRICE_RANGES, type Category, type PriceRange } from '@/types'

export default function FilterBar() {
  const [cat, setCat]     = useState<Category | 'all'>('all')
  const [price, setPrice] = useState<PriceRange>('all')

  function emitCat(c: Category | 'all') {
    setCat(c)
    window.dispatchEvent(new CustomEvent('hpl-cat', { detail: c }))
  }

  function emitPrice(p: PriceRange) {
    setPrice(p)
    window.dispatchEvent(new CustomEvent('hpl-price', { detail: p }))
  }

  return (
    <div className="sticky top-[62px] z-40 bg-bg-secondary border-b border-border">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex items-center gap-2 overflow-x-auto py-3 scrollbar-none no-scrollbar">
          {/* Category filters */}
          <div className="flex gap-1.5 flex-shrink-0">
            <button
              onClick={() => emitCat('all')}
              className={`filter-pill ${cat === 'all' ? 'active' : ''}`}
            >
              All
            </button>
            {CATEGORIES.map(c => (
              <button
                key={c}
                onClick={() => emitCat(c)}
                className={`filter-pill ${cat === c ? 'active' : ''}`}
              >
                {c}
              </button>
            ))}
          </div>

          {/* Divider */}
          <div className="w-px h-5 bg-border-strong flex-shrink-0 mx-1" />

          {/* Price filters */}
          <div className="flex gap-1.5 flex-shrink-0">
            {PRICE_RANGES.map(r => (
              <button
                key={r.value}
                onClick={() => emitPrice(r.value)}
                className={`filter-pill price ${price === r.value ? 'active' : ''}`}
              >
                {r.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <style jsx>{`
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}</style>
    </div>
  )
}
