'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Search, X } from 'lucide-react'

export default function Navbar() {
  const [open, setOpen] = useState(false)

  return (
    <nav className="glass-nav sticky top-0 z-50 border-b border-border h-[62px] flex items-center px-5 gap-4">
      <Link href="/" className="font-display text-[22px] font-bold tracking-widest text-text-primary flex-shrink-0">
        HPL<span className="text-accent-cyan">Shares</span>
      </Link>

      <div className="ml-auto flex items-center gap-3">
        {/* Desktop search */}
        <div className="relative hidden sm:flex items-center">
          <Search size={15} className="absolute left-3 text-text-muted pointer-events-none" />
          <input
            id="navbar-search"
            type="text"
            placeholder="Search products..."
            className="input-dark pl-9 w-[240px] focus:w-[290px] transition-all duration-300 rounded-pill"
            onChange={e => {
              const ev = new CustomEvent('hpl-search', { detail: e.target.value })
              window.dispatchEvent(ev)
            }}
          />
        </div>

        {/* Mobile search toggle */}
        <button
          className="sm:hidden text-text-secondary p-1.5"
          onClick={() => setOpen(o => !o)}
          aria-label="Search"
        >
          {open ? <X size={20} /> : <Search size={20} />}
        </button>
      </div>

      {/* Mobile search drawer */}
      {open && (
        <div className="absolute top-[62px] left-0 right-0 bg-bg-secondary border-b border-border px-4 py-3 sm:hidden z-40">
          <input
            autoFocus
            type="text"
            placeholder="Search products..."
            className="input-dark rounded-pill"
            onChange={e => {
              const ev = new CustomEvent('hpl-search', { detail: e.target.value })
              window.dispatchEvent(ev)
            }}
          />
        </div>
      )}
    </nav>
  )
}
