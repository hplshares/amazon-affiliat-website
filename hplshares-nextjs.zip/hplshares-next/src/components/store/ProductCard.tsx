import Image from 'next/image'
import Link from 'next/link'
import { type Product, formatPrice } from '@/types'

interface Props {
  product: Product
  index:   number
}

export default function ProductCard({ product, index }: Props) {
  const { name, cat, price, link, img, featured } = product

  const waText = encodeURIComponent(
    `Check out *${name}*${price ? ' - ' + formatPrice(price) : ''}\nBuy here: ${link}\n\nvia *HPL Shares* | instagram.com/hpl_shares`
  )
  const waLink = `https://wa.me/?text=${waText}`

  return (
    <article
      className={`
        bg-bg-card border rounded-card flex flex-col overflow-hidden card-hover animate-fade-up
        ${featured ? 'border-[rgba(0,119,255,0.3)] hover:border-accent-blue' : 'border-border hover:border-border-strong'}
      `}
      style={{ animationDelay: `${index * 0.04}s` }}
    >
      {/* Image */}
      <div className="relative w-full h-[168px] bg-bg-tertiary overflow-hidden">
        {img ? (
          <Image
            src={img}
            alt={name}
            fill
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 20vw"
            className="object-cover transition-transform duration-300 group-hover:scale-105"
            loading="lazy"
            unoptimized={img.includes('amazon')}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-text-muted text-xs">
            No Image
          </div>
        )}
        {featured && (
          <span className="absolute top-2.5 left-2.5 bg-accent-blue text-white text-[10px] font-medium px-2 py-0.5 rounded-[5px] tracking-wide">
            HPL Pick
          </span>
        )}
      </div>

      {/* Body */}
      <div className="flex flex-col flex-1 p-3.5 gap-1">
        <span className="text-[10px] font-medium text-accent-cyan tracking-[1.2px] uppercase">
          {cat}
        </span>
        <h2 className="text-sm font-medium text-text-primary leading-snug line-clamp-2">
          {name}
        </h2>
        {price > 0 && (
          <p className="text-[13px] text-text-secondary mt-0.5">
            {formatPrice(price)}
          </p>
        )}

        {/* Actions */}
        <div className="flex gap-2 mt-auto pt-2.5">
          <Link
            href={link}
            target="_blank"
            rel="noopener noreferrer sponsored"
            className="btn-cyan flex-1 text-center text-[13px] py-2"
            aria-label={`Buy ${name} on Amazon`}
          >
            Buy on Amazon
          </Link>
          <Link
            href={waLink}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`Share ${name} on WhatsApp`}
            className="flex items-center justify-center w-9 h-9 rounded-btn bg-[#1a2a1e] border border-[#1f4028] text-[#25d366] hover:bg-[#1f3324] transition-colors duration-150 flex-shrink-0"
          >
            <svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16" aria-hidden="true">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
            </svg>
          </Link>
        </div>
      </div>
    </article>
  )
}
