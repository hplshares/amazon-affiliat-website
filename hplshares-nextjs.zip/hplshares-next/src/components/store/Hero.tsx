export default function Hero() {
  return (
    <section className="relative overflow-hidden px-5 pt-16 pb-12 text-center">
      {/* Grid background */}
      <div className="hero-grid absolute inset-0 pointer-events-none" />

      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-bg-primary to-transparent pointer-events-none" />

      <div className="relative z-10 max-w-2xl mx-auto">
        <div className="inline-block bg-[rgba(0,224,255,0.08)] border border-[rgba(0,224,255,0.18)] text-accent-cyan text-[11px] font-medium tracking-[1.5px] uppercase px-4 py-1.5 rounded-pill mb-5">
          Curated by HPL
        </div>

        <h1 className="font-display text-[clamp(36px,6vw,58px)] font-bold leading-[1.1] tracking-tight mb-3">
          Handpicked Tech.<br />
          <span className="text-accent-cyan">Zero Confusion.</span>
        </h1>

        <p className="text-text-secondary text-base max-w-md mx-auto">
          Products I personally use, test and recommend — for every budget.
        </p>
      </div>
    </section>
  )
}
