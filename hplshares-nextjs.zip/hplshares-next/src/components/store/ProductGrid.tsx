'use client'

import { useState, useEffect, useCallback } from 'react'
import ProductCard from './ProductCard'
import { type Product, type Category, type PriceRange, matchesPrice } from '@/types'

interface Props {
  initialProducts: Product[]
}

export default function ProductGrid({ initialProducts }: Props) {
  const [products]  = useState<Product[]>(initialProducts)
  const [query,     setQuery]     = useState('')
  const [cat,       setCat]       = useState<Category | 'all'>('all')
  const [priceRange, setPriceRange] = useState<PriceRange>('all')

  // Listen to events from Navbar and FilterBar
  useEffect(() => {
    const onSearch = (e: Event) => setQuery((e as CustomEvent).detail as string)
    const onCat    = (e: Event) => setCat((e as CustomEvent).detail as Category | 'all')
    const onPrice  = (e: Event) => setPriceRange((e as CustomEvent).detail as PriceRange)

    window.addEventListener('hpl-search', onSearch)
    window.addEventListener('hpl-cat',    onCat)
    window.addEventListener('hpl-price',  onPrice)
    return () => {
      window.removeEventListener('hpl-search', onSearch)
      window.removeEventListener('hpl-cat',    onCat)
      window.removeEventListener('hpl-price',  onPrice)
    }
  }, [])

  const filtered = useCallback(() => {
    const q = query.toLowerCase().trim()
    return products.filter(p => {
      const matchCat    = cat === 'all' || p.cat === cat
      const matchSearch = !q || p.name.toLowerCase().includes(q) || p.cat.toLowerCase().includes(q)
      const matchPrice  = matchesPrice(p.price, priceRange)
      return matchCat && matchSearch && matchPrice
    })
  }, [products, query, cat, priceRange])

  const all      = filtered()
  const featured = all.filter(p => p.featured)
  const rest     = all

  return (
    <main className="max-w-6xl mx-auto px-4 pb-16">

      {/* Featured */}
      {featured.length > 0 && (
        <>
          <SectionLabel color="cyan" label="Featured Picks" />
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 md:gap-4">
            {featured.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        </>
      )}

      {/* All products */}
      {rest.length > 0 && (
        <>
          <SectionLabel
            color="blue"
            label="All Products"
            count={rest.length}
          />
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 md:gap-4">
            {rest.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        </>
      )}

      {/* Empty state */}
      {all.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 text-text-muted gap-3">
          <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
          </svg>
          <h3 className="text-lg font-medium text-text-secondary">No products found</h3>
          <p className="text-sm">Try a different search or filter</p>
        </div>
      )}
    </main>
  )
}

function SectionLabel({
  color, label, count,
}: {
  color: 'cyan' | 'blue'
  label: string
  count?: number
}) {
  return (
    <div className="flex items-center gap-3 pt-9 pb-4">
      <span
        className={`w-2 h-2 rounded-full flex-shrink-0 ${color === 'cyan' ? 'bg-accent-cyan' : 'bg-accent-blue'}`}
      />
      <h2 className="font-display text-xl font-bold tracking-wide text-text-secondary">
        {label}
      </h2>
      {count !== undefined && (
        <span className="text-xs text-text-muted">
          {count} product{count !== 1 ? 's' : ''}
        </span>
      )}
      <div className="flex-1 h-px bg-border" />
    </div>
  )
}
