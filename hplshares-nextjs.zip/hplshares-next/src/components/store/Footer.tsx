import Link from 'next/link'

export default function Footer() {
  const ig  = process.env.NEXT_PUBLIC_INSTAGRAM || 'https://instagram.com/hpl_shares'
  const yt  = process.env.NEXT_PUBLIC_YOUTUBE   || 'https://youtube.com/@thecybermandotco'

  return (
    <footer className="border-t border-border bg-bg-secondary mt-4">
      <div className="max-w-xl mx-auto px-5 py-10 text-center">
        <div className="font-display text-[22px] font-bold tracking-widest mb-1">
          HPL<span className="text-accent-cyan">Shares</span>
        </div>
        <p className="text-sm text-text-muted mt-1">
          Curated tech picks by <strong className="text-text-secondary">Hitesh Prakash Loya</strong>
        </p>
        <div className="flex justify-center gap-5 mt-4 text-sm">
          <Link href={ig} target="_blank" rel="noopener noreferrer"
            className="text-text-secondary hover:text-accent-cyan transition-colors">
            Instagram
          </Link>
          <Link href={yt} target="_blank" rel="noopener noreferrer"
            className="text-text-secondary hover:text-accent-cyan transition-colors">
            YouTube
          </Link>
        </div>
        <p className="text-[11px] text-text-muted mt-5 leading-relaxed max-w-sm mx-auto">
          As an Amazon Associate, I earn from qualifying purchases.<br />
          Prices are approximate and subject to change.
        </p>
        <p className="text-[11px] text-text-muted mt-3">
          &copy; {new Date().getFullYear()} HPL Shares. All rights reserved.
        </p>
      </div>
    </footer>
  )
}
