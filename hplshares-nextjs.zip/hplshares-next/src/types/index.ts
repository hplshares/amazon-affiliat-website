export type Category =
  | 'Mobiles'
  | 'Laptops'
  | 'Accessories'
  | 'Gadgets'
  | 'Smart Home'
  | 'Books'

export type PriceRange = 'all' | 'budget' | 'mid' | 'premium' | 'high'

export interface Product {
  id:         string
  name:       string
  cat:        Category
  price:      number
  link:       string
  img:        string
  featured:   boolean
  visible:    boolean
  createdAt:  number
  updatedAt:  number
}

export type ProductInput = Omit<Product, 'id' | 'createdAt' | 'updatedAt'>

export const CATEGORIES: Category[] = [
  'Mobiles',
  'Laptops',
  'Accessories',
  'Gadgets',
  'Smart Home',
  'Books',
]

export const PRICE_RANGES: { label: string; value: PriceRange }[] = [
  { label: 'All Prices',   value: 'all'     },
  { label: 'Under ₹999',  value: 'budget'  },
  { label: '₹1K - 5K',    value: 'mid'     },
  { label: '₹5K - 20K',   value: 'premium' },
  { label: '₹20K+',       value: 'high'    },
]

export function matchesPrice(price: number, range: PriceRange): boolean {
  if (range === 'all')     return true
  if (range === 'budget')  return price < 1000
  if (range === 'mid')     return price >= 1000 && price <= 5000
  if (range === 'premium') return price > 5000 && price <= 20000
  if (range === 'high')    return price > 20000
  return true
}

export function formatPrice(price: number): string {
  return '₹' + price.toLocaleString('en-IN')
}
