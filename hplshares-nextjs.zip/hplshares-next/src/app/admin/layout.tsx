import { redirect } from 'next/navigation'
import { cookies } from 'next/headers'
import { adminAuth } from '@/lib/firebase-admin'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title:  'Admin Panel - HPL Shares',
  robots: { index: false, follow: false },
}

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  // Allow login page through without auth check
  return <>{children}</>
}
