'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import toast from 'react-hot-toast'
import { Plus, LogOut, ExternalLink, Pencil, Trash2, Eye, EyeOff } from 'lucide-react'
import { type Product, type Category, CATEGORIES, formatPrice } from '@/types'

export default function AdminDashboard() {
  const router   = useRouter()
  const [products, setProducts] = useState<Product[]>([])
  const [loading,  setLoading]  = useState(true)
  const [saving,   setSaving]   = useState(false)
  const [editId,   setEditId]   = useState<string | null>(null)
  const [search,   setSearch]   = useState('')
  const [imgPrev,  setImgPrev]  = useState('')

  const blank = { name:'', cat:'' as Category, price:'', link:'', img:'', featured:false, visible:true }
  const [form, setForm] = useState(blank)

  useEffect(() => { loadProducts() }, [])

  async function loadProducts() {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/products')
      if (res.status === 401) { router.push('/admin/login'); return }
      const data = await res.json()
      setProducts(data.products || [])
    } catch { toast.error('Failed to load products') }
    finally { setLoading(false) }
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault()
    if (!form.name || !form.cat || !form.link) { toast.error('Name, category and link are required'); return }
    setSaving(true)
    try {
      const body = { ...form, price: parseInt(String(form.price)) || 0 }
      const res = editId
        ? await fetch(`/api/admin/products/${editId}`, { method:'PUT',  headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) })
        : await fetch('/api/admin/products',             { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) })
      if (!res.ok) throw new Error()
      toast.success(editId ? 'Product updated!' : 'Product added!')
      resetForm()
      await loadProducts()
    } catch { toast.error('Failed to save product') }
    finally { setSaving(false) }
  }

  async function handleDelete(id: string, name: string) {
    if (!confirm(`Delete "${name}"? This cannot be undone.`)) return
    try {
      const res = await fetch(`/api/admin/products/${id}`, { method:'DELETE' })
      if (!res.ok) throw new Error()
      toast.success('Product deleted')
      setProducts(p => p.filter(x => x.id !== id))
    } catch { toast.error('Failed to delete') }
  }

  async function handleLogout() {
    await fetch('/api/auth', { method:'DELETE' })
    router.push('/admin/login')
  }

  function startEdit(p: Product) {
    setEditId(p.id)
    setForm({ name:p.name, cat:p.cat, price:String(p.price), link:p.link, img:p.img||'', featured:p.featured, visible:p.visible })
    setImgPrev(p.img||'')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  function resetForm() {
    setEditId(null)
    setForm(blank)
    setImgPrev('')
  }

  function field(key: keyof typeof form, val: any) {
    setForm(f => ({ ...f, [key]: val }))
    if (key === 'img') setImgPrev(val)
  }

  const total    = products.length
  const featured = products.filter(p => p.featured).length
  const cats     = new Set(products.map(p => p.cat)).size
  const live     = products.filter(p => p.visible).length
  const filtered = search
    ? products.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) || p.cat.toLowerCase().includes(search.toLowerCase()))
    : products

  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Nav */}
      <nav className="glass-nav sticky top-0 z-50 border-b border-border h-[62px] flex items-center px-5 gap-4">
        <a href="/" className="font-display text-[20px] font-bold tracking-widest text-text-primary">
          HPL<span className="text-accent-cyan">Shares</span>
        </a>
        <span className="text-[11px] text-text-muted uppercase tracking-widest hidden sm:block">Admin Panel</span>
        <div className="ml-auto flex gap-2">
          <a href="/" target="_blank" rel="noopener noreferrer"
            className="flex items-center gap-1.5 border border-border-strong text-text-secondary text-sm px-3 py-1.5 rounded-btn hover:border-accent-cyan hover:text-accent-cyan transition-colors">
            <ExternalLink size={13} /> Store
          </a>
          <button onClick={handleLogout}
            className="flex items-center gap-1.5 border border-[#3a1c1c] text-red-400 text-sm px-3 py-1.5 rounded-btn hover:bg-red-400/10 transition-colors">
            <LogOut size={13} /> Logout
          </button>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 py-7 pb-16">

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
          {[
            { label:'Total Products', val: total },
            { label:'Featured',       val: featured },
            { label:'Categories',     val: cats },
            { label:'Live on Store',  val: live },
          ].map(s => (
            <div key={s.label} className="bg-bg-card border border-border rounded-[10px] p-4 text-center">
              <div className="font-display text-[28px] font-bold text-accent-cyan leading-none">{loading ? '-' : s.val}</div>
              <div className="text-[12px] text-text-muted mt-1">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Form */}
        <div className="bg-bg-card border border-border rounded-card p-6 mb-5">
          <h2 className="text-[15px] font-medium text-accent-cyan mb-5">
            {editId ? 'Edit Product' : '+ Add New Product'}
          </h2>
          <form onSubmit={handleSave} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-medium text-text-muted uppercase tracking-[0.8px] mb-1.5">Product Name *</label>
                <input value={form.name} onChange={e => field('name', e.target.value)} placeholder="e.g. boAt Airdopes 141" required className="input-dark" />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-text-muted uppercase tracking-[0.8px] mb-1.5">Category *</label>
                <select value={form.cat} onChange={e => field('cat', e.target.value)} required className="input-dark">
                  <option value="">Select category</option>
                  {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-medium text-text-muted uppercase tracking-[0.8px] mb-1.5">Price (₹) *</label>
                <input type="number" value={form.price} onChange={e => field('price', e.target.value)} placeholder="e.g. 1299" className="input-dark" />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-text-muted uppercase tracking-[0.8px] mb-1.5">Amazon Affiliate Link *</label>
                <input type="url" value={form.link} onChange={e => field('link', e.target.value)} placeholder="https://amzn.to/..." required className="input-dark" />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-text-muted uppercase tracking-[0.8px] mb-1.5">Product Image URL</label>
              <input type="url" value={form.img} onChange={e => field('img', e.target.value)} placeholder="https://m.media-amazon.com/..." className="input-dark" />
              {imgPrev && (
                <div className="mt-2 relative w-[80px] h-[80px] rounded-btn border border-border overflow-hidden">
                  <Image src={imgPrev} alt="Preview" fill className="object-cover" unoptimized onError={() => setImgPrev('')} />
                </div>
              )}
            </div>

            <div className="flex flex-wrap gap-5">
              <label className="flex items-center gap-2.5 cursor-pointer">
                <input type="checkbox" checked={form.featured} onChange={e => field('featured', e.target.checked)} className="w-4 h-4 accent-[#00e0ff]" />
                <span className="text-sm text-text-primary">Mark as Featured Pick</span>
              </label>
              <label className="flex items-center gap-2.5 cursor-pointer">
                <input type="checkbox" checked={form.visible} onChange={e => field('visible', e.target.checked)} className="w-4 h-4 accent-[#00e0ff]" />
                <span className="text-sm text-text-primary">Show on Store (Live)</span>
              </label>
            </div>

            <div className="flex gap-3 pt-1">
              <button type="submit" disabled={saving} className="btn-cyan disabled:opacity-50 disabled:cursor-not-allowed">
                {saving ? 'Saving...' : editId ? 'Update Product' : 'Add Product'}
              </button>
              {editId && (
                <button type="button" onClick={resetForm}
                  className="border border-border-strong text-text-secondary text-sm px-4 py-2.5 rounded-btn hover:border-text-muted transition-colors">
                  Cancel
                </button>
              )}
            </div>
          </form>
        </div>

        {/* Product list */}
        <div className="bg-bg-card border border-border rounded-card p-6">
          <div className="flex items-center justify-between gap-3 mb-5 flex-wrap">
            <h2 className="text-[15px] font-medium text-accent-cyan">All Products</h2>
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search..."
              className="input-dark w-[200px]"
            />
          </div>

          {loading ? (
            <div className="flex justify-center py-12"><div className="spinner" /></div>
          ) : filtered.length === 0 ? (
            <p className="text-center text-text-muted text-sm py-8">No products yet. Add your first one above.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr>
                    {['Product','Category','Price','Status','Actions'].map(h => (
                      <th key={h} className="text-left text-[11px] font-medium text-text-muted uppercase tracking-[0.7px] px-3 py-2 border-b border-border">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map(p => (
                    <tr key={p.id} className="hover:bg-white/[0.02] transition-colors">
                      <td className="px-3 py-3 border-b border-border">
                        <div className="flex items-center gap-2.5">
                          {p.img ? (
                            <div className="relative w-9 h-9 flex-shrink-0 rounded-[6px] border border-border overflow-hidden">
                              <Image src={p.img} alt={p.name} fill className="object-cover" unoptimized />
                            </div>
                          ) : (
                            <div className="w-9 h-9 flex-shrink-0 rounded-[6px] border border-border bg-bg-tertiary" />
                          )}
                          <div>
                            <div className="font-medium text-text-primary line-clamp-1 max-w-[180px]">{p.name}</div>
                            {p.featured && (
                              <span className="text-[10px] bg-accent-blue/15 text-[#5badff] px-1.5 py-0.5 rounded mt-0.5 inline-block">Featured</span>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="px-3 py-3 border-b border-border">
                        <span className="text-[11px] bg-[rgba(0,224,255,0.08)] text-accent-cyan px-2 py-0.5 rounded">{p.cat}</span>
                      </td>
                      <td className="px-3 py-3 border-b border-border text-text-secondary">
                        {p.price ? formatPrice(p.price) : '-'}
                      </td>
                      <td className="px-3 py-3 border-b border-border">
                        <span className={`text-[12px] flex items-center gap-1 ${p.visible ? 'text-accent-cyan' : 'text-text-muted'}`}>
                          {p.visible ? <Eye size={12} /> : <EyeOff size={12} />}
                          {p.visible ? 'Live' : 'Hidden'}
                        </span>
                      </td>
                      <td className="px-3 py-3 border-b border-border">
                        <div className="flex gap-1.5">
                          <button onClick={() => startEdit(p)}
                            className="p-1.5 rounded bg-accent-blue/10 border border-accent-blue/25 text-[#5badff] hover:bg-accent-blue/20 transition-colors">
                            <Pencil size={13} />
                          </button>
                          <button onClick={() => handleDelete(p.id, p.name)}
                            className="p-1.5 rounded bg-red-400/10 border border-red-400/20 text-red-400 hover:bg-red-400/20 transition-colors">
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
