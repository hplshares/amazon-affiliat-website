'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { signInWithEmailAndPassword } from 'firebase/auth'
import { auth } from '@/lib/firebase'
import { Eye, EyeOff, Lock } from 'lucide-react'

export default function AdminLoginPage() {
  const router = useRouter()
  const [email,    setEmail]    = useState('')
  const [password, setPassword] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [loading,  setLoading]  = useState(false)
  const [error,    setError]    = useState('')

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      const cred = await signInWithEmailAndPassword(auth, email, password)
      const idToken = await cred.user.getIdToken()

      // Exchange for session cookie via API
      const res = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken }),
      })

      if (!res.ok) {
        const data = await res.json()
        throw new Error(data.error || 'Login failed')
      }

      router.push('/admin/dashboard')
    } catch (err: any) {
      const msg = err?.message || 'Login failed'
      if (msg.includes('invalid-credential') || msg.includes('wrong-password')) {
        setError('Incorrect email or password.')
      } else if (msg.includes('Unauthorized')) {
        setError('This account is not authorized as admin.')
      } else {
        setError(msg)
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-bg-primary">
      <div className="w-full max-w-sm">
        {/* Card */}
        <div className="bg-bg-card border border-border rounded-card px-8 py-10 text-center">
          <div className="font-display text-[26px] font-bold tracking-widest mb-1">
            HPL<span className="text-accent-cyan">Shares</span>
          </div>
          <p className="text-text-muted text-[13px] mb-8 tracking-wide uppercase">Admin Access</p>

          <div className="w-10 h-10 rounded-full bg-[rgba(0,224,255,0.08)] border border-[rgba(0,224,255,0.15)] flex items-center justify-center mx-auto mb-6">
            <Lock size={18} className="text-accent-cyan" />
          </div>

          <form onSubmit={handleLogin} className="text-left space-y-4">
            <div>
              <label className="block text-[11px] font-medium text-text-muted uppercase tracking-[0.8px] mb-1.5">
                Email
              </label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="admin@example.com"
                required
                autoComplete="email"
                className="input-dark"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-text-muted uppercase tracking-[0.8px] mb-1.5">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPass ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  autoComplete="current-password"
                  className="input-dark pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(s => !s)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-text-secondary transition-colors"
                  aria-label="Toggle password visibility"
                >
                  {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            {error && (
              <p className="text-[13px] text-red-400 bg-red-400/10 border border-red-400/20 rounded-btn px-3 py-2">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="btn-cyan w-full mt-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>
        </div>

        <p className="text-center text-[12px] text-text-muted mt-4">
          &larr; <a href="/" className="hover:text-accent-cyan transition-colors">Back to Store</a>
        </p>
      </div>
    </div>
  )
}
