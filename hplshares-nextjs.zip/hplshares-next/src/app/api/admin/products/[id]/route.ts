import { NextRequest, NextResponse } from 'next/server'
import { adminDb, adminAuth } from '@/lib/firebase-admin'
import { cookies } from 'next/headers'

async function verifyAdmin(): Promise<boolean> {
  try {
    const session = cookies().get('hpl_session')?.value
    if (!session) return false
    await adminAuth.verifySessionCookie(session, true)
    return true
  } catch {
    return false
  }
}

// PUT /api/admin/products/[id] - update product
export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  if (!(await verifyAdmin())) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const body = await req.json()
    const { name, cat, price, link, img, featured, visible } = body

    if (!name || !cat || !link) {
      return NextResponse.json({ error: 'Name, category and link are required' }, { status: 400 })
    }

    await adminDb.collection('products').doc(params.id).update({
      name:      String(name).slice(0, 200),
      cat:       String(cat),
      price:     Math.abs(parseInt(price) || 0),
      link:      String(link).slice(0, 500),
      img:       String(img || '').slice(0, 500),
      featured:  Boolean(featured),
      visible:   Boolean(visible),
      updatedAt: Date.now(),
    })

    return NextResponse.json({ success: true })
  } catch (err) {
    return NextResponse.json({ error: 'Failed to update' }, { status: 500 })
  }
}

// DELETE /api/admin/products/[id]
export async function DELETE(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  if (!(await verifyAdmin())) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    await adminDb.collection('products').doc(params.id).delete()
    return NextResponse.json({ success: true })
  } catch (err) {
    return NextResponse.json({ error: 'Failed to delete' }, { status: 500 })
  }
}
