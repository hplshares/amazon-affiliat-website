import { NextRequest, NextResponse } from 'next/server'
import { adminDb, adminAuth } from '@/lib/firebase-admin'
import { cookies } from 'next/headers'

async function verifyAdmin(): Promise<boolean> {
  try {
    const session = cookies().get('hpl_session')?.value
    if (!session) return false
    await adminAuth.verifySessionCookie(session, true)
    return true
  } catch {
    return false
  }
}

// GET /api/admin/products - all products including hidden
export async function GET() {
  if (!(await verifyAdmin())) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const snap = await adminDb
      .collection('products')
      .orderBy('createdAt', 'desc')
      .get()

    const products = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }))
    return NextResponse.json({ products })
  } catch (err) {
    return NextResponse.json({ error: 'Failed to fetch' }, { status: 500 })
  }
}

// POST /api/admin/products - create product
export async function POST(req: NextRequest) {
  if (!(await verifyAdmin())) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const body = await req.json()
    const { name, cat, price, link, img, featured, visible } = body

    if (!name || !cat || !link) {
      return NextResponse.json({ error: 'Name, category and link are required' }, { status: 400 })
    }

    const now = Date.now()
    const ref = await adminDb.collection('products').add({
      name:      String(name).slice(0, 200),
      cat:       String(cat),
      price:     Math.abs(parseInt(price) || 0),
      link:      String(link).slice(0, 500),
      img:       String(img || '').slice(0, 500),
      featured:  Boolean(featured),
      visible:   Boolean(visible),
      createdAt: now,
      updatedAt: now,
    })

    return NextResponse.json({ id: ref.id }, { status: 201 })
  } catch (err) {
    return NextResponse.json({ error: 'Failed to create product' }, { status: 500 })
  }
}
