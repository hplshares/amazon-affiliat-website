import { NextRequest, NextResponse } from 'next/server'
import { adminAuth } from '@/lib/firebase-admin'
import { cookies } from 'next/headers'

// POST /api/auth - exchange Firebase ID token for session cookie
export async function POST(req: NextRequest) {
  try {
    const { idToken } = await req.json()
    if (!idToken) {
      return NextResponse.json({ error: 'Missing token' }, { status: 400 })
    }

    // Verify with Firebase Admin
    const decoded = await adminAuth.verifyIdToken(idToken)

    // Check admin claim or allowed email
    const ADMIN_EMAIL = process.env.FIREBASE_ADMIN_CLIENT_EMAIL
    const allowedEmails = (process.env.ADMIN_ALLOWED_EMAILS || ADMIN_EMAIL || '').split(',')

    if (!allowedEmails.includes(decoded.email || '')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 })
    }

    // Set secure httpOnly session cookie (5 days)
    const expiresIn = 60 * 60 * 24 * 5 * 1000
    const sessionCookie = await adminAuth.createSessionCookie(idToken, { expiresIn })

    cookies().set('hpl_session', sessionCookie, {
      maxAge:   expiresIn / 1000,
      httpOnly: true,
      secure:   process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path:     '/',
    })

    return NextResponse.json({ success: true })
  } catch (err) {
    console.error('Auth error:', err)
    return NextResponse.json({ error: 'Authentication failed' }, { status: 401 })
  }
}

// DELETE /api/auth - logout
export async function DELETE() {
  cookies().delete('hpl_session')
  return NextResponse.json({ success: true })
}
