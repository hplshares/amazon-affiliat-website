import type { Metadata } from 'next'
import { adminDb } from '@/lib/firebase-admin'
import { Product } from '@/types'
import Navbar from '@/components/store/Navbar'
import Hero from '@/components/store/Hero'
import FilterBar from '@/components/store/FilterBar'
import ProductGrid from '@/components/store/ProductGrid'
import Footer from '@/components/store/Footer'

export const revalidate = 60

export const metadata: Metadata = {
  title: 'HPL Shares - Handpicked Tech Picks',
  description:
    'Tech products personally curated and recommended by HPL. Mobiles, laptops, gadgets and accessories - best picks for every budget in India.',
}

async function getProducts(): Promise<Product[]> {
  try {
    const snap = await adminDb
      .collection('products')
      .where('visible', '==', true)
      .orderBy('createdAt', 'desc')
      .get()
    return snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product))
  } catch (err) {
    console.error('Failed to load products:', err)
    return []
  }
}

export default async function HomePage() {
  const products = await getProducts()

  // JSON-LD structured data for Google
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type':    'WebSite',
    name:       'HPL Shares',
    url:        process.env.NEXT_PUBLIC_SITE_URL || 'https://hplshares.in',
    description: 'Tech products personally curated by HPL',
    author: {
      '@type': 'Person',
      name:    'Hitesh Prakash Loya',
      sameAs:  [
        'https://instagram.com/hpl_shares',
        'https://youtube.com/@thecybermandotco',
      ],
    },
    potentialAction: {
      '@type':       'SearchAction',
      target:        `${process.env.NEXT_PUBLIC_SITE_URL}/?q={search_term_string}`,
      'query-input': 'required name=search_term_string',
    },
  }

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      {/* Affiliate disclosure */}
      <div className="bg-bg-secondary border-b border-border text-center py-1.5 px-4 text-xs text-text-muted tracking-wide">
        As an Amazon Associate, I earn from qualifying purchases. Prices shown are approximate.
      </div>

      <Navbar />
      <Hero />
      <FilterBar />
      <ProductGrid initialProducts={products} />
      <Footer />
    </>
  )
}
