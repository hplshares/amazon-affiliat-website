import { MetadataRoute } from 'next'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://hplshares.in'

export default function sitemap(): MetadataRoute.Sitemap {
  return [
    {
      url:              SITE_URL,
      lastModified:     new Date(),
      changeFrequency:  'daily',
      priority:         1,
    },
    {
      url:              `${SITE_URL}/admin/login`,
      lastModified:     new Date(),
      changeFrequency:  'never',
      priority:         0,
    },
  ]
}
