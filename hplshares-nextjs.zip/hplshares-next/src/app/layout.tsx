import type { Metadata } from 'next'
import { Toaster } from 'react-hot-toast'
import './globals.css'

const SITE_URL  = process.env.NEXT_PUBLIC_SITE_URL  || 'https://hplshares.in'
const SITE_NAME = process.env.NEXT_PUBLIC_SITE_NAME || 'HPL Shares'

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default:  `${SITE_NAME} - Handpicked Tech Picks`,
    template: `%s | ${SITE_NAME}`,
  },
  description:
    'Tech products personally curated and recommended by HPL - cybersecurity expert and tech creator. Gadgets, laptops, mobiles and accessories for every budget.',
  keywords: [
    'tech recommendations India',
    'best gadgets India',
    'Amazon deals India',
    'HPL Shares',
    'best mobile phone India',
    'laptop recommendations',
    'cybersecurity tools',
    'tech accessories',
  ],
  authors: [{ name: 'Hitesh Prakash Loya', url: 'https://instagram.com/hpl_shares' }],
  creator: 'Hitesh Prakash Loya',
  openGraph: {
    type:      'website',
    locale:    'en_IN',
    url:       SITE_URL,
    siteName:  SITE_NAME,
    title:     `${SITE_NAME} - Handpicked Tech Picks`,
    description:
      'Tech products personally curated and recommended by HPL. Zero confusion, just great picks.',
    images: [
      {
        url:    '/og-image.png',
        width:  1200,
        height: 630,
        alt:    'HPL Shares - Handpicked Tech Picks',
      },
    ],
  },
  twitter: {
    card:        'summary_large_image',
    title:       `${SITE_NAME} - Handpicked Tech Picks`,
    description: 'Tech products personally curated by HPL.',
    images:      ['/og-image.png'],
  },
  robots: {
    index:               true,
    follow:              true,
    googleBot: {
      index:             true,
      follow:            true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet':       -1,
    },
  },
  icons: {
    icon:    '/favicon.svg',
    apple:   '/apple-touch-icon.png',
  },
  alternates: {
    canonical: SITE_URL,
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en-IN">
      <body>
        <Toaster
          position="bottom-right"
          toastOptions={{
            style: {
              background: '#00e0ff',
              color:      '#000',
              fontWeight: '500',
              fontSize:   '14px',
              borderRadius: '10px',
            },
          }}
        />
        {children}
      </body>
    </html>
  )
}
